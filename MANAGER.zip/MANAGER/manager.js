const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const { Pool } = require("pg");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 5501;

// db connection
const pool = new Pool({
  user: "doadmin",
  password: "AVNS_D83ixMFE3Kn5ddMVQQz",
  host: "db-postgresql-fra1-56784-do-user-15448575-0.c.db.ondigitalocean.com",
  port: "25060",
  database: "defaultdb",
  ssl: {
    ca: fs.readFileSync(path.join(__dirname, "ca-certificate.crt")), // CA certificate for Database
  },
});

// Session middleware configuration
app.use(
  session({ secret: "your-secret-key", resave: false, saveUninitialized: true })
);

// Static file serving
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(
  "/JourneyToHope/MANAGER/css",
  express.static(path.join(__dirname, "css"))
);
app.use(
  "/JourneyToHope/MANAGER/js",
  express.static(path.join(__dirname, "js"))
);
app.use(
  "/JourneyToHope/MANAGER/img",
  express.static(path.join(__dirname, "img"))
);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

// Ana sayfa
app.get("/", (req, res) => {
  res.render("managerLogin");
});

app.get("/managerTotal", (req, res) => {
  res.render("managerTotal");
});

app.get("/managerUploadChildren", (req, res) => {
  res.render("managerUploadChildren");
});

app.get("/managerPage", (req, res) => {
  res.render("managerPage");
});

/* Login Page */
app.get("/managerLogin", (req, res) => {
  res.render("managerLogin");
});

app.post("/managerLogin", (req, res) => {
  const { manageremail, managerpassword } = req.body;

  pool.query(
    'SELECT * FROM public."manager" WHERE manageremail = $1 AND managerpassword = $2',
    [manageremail, managerpassword],
    (error, result) => {
      if (error) {
        console.error("Error executing SELECT query:", error);
        res.status(500).send("Internal Server Error");
      } else {
        if (result.rows.length > 0) {
          req.session.userId = result.rows[0].id;
          req.session.manageremail = result.rows[0].manageremail;
          res.redirect("managerPage");
        } else {
          res.send("Wrong Email or Password");
        }
      }
    }
  );
});

app.get("/managerLogout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.redirect("/");
    }
    res.redirect("managerPage");
  });
});

/* Sponsor Contact Verileri */
app.get("/managerSponsorContact", (req, res) => {
  pool.query("SELECT * FROM sponsor", (err, result) => {
    if (err) {
      console.error("Veritabanından veri çekerken hata oluştu:", err);
      return res.status(500).json({ error: err.message });
    }

    const sponsors = result.rows;
    res.render("managerSponsorContact", { sponsors });
  });
});

// Dosya yükleme için multer konfigürasyonu
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: { fileSize: 1024 * 1024 }, // 1 MB sınırlama örneği, ihtiyaca göre değiştirilebilir
  fileFilter: (req, file, cb) => {
    if (file.fieldname === "photoedit") {
      // beklenen alan adı doğruysa devam et
      cb(null, true);
    } else {
      // beklenen alan adı değilse hata döndür
      cb(new Error("Unexpected field"));
    }
  },
});

// managerUploadChildren route'u
app.post("/managerUploadChildren", upload.single("photoedit"), (req, res) => {
  try {
    const { childid, fullname, age, gender, location, needs } = req.body;

    if (req.file && req.file.buffer) {
      const childphoto = req.file.buffer;

      const query = `
        INSERT INTO childrens (childid, fullname, age, gender, location, needs, childphoto)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
      `;

      const values = [
        childid,
        fullname,
        age,
        gender,
        location,
        needs,
        childphoto,
      ];

      pool.query(query, values, (error, result) => {
        if (error) {
          console.error("Veritabanına veri eklerken hata oluştu:", error);
          res.status(500).send("Internal Server Error");
        } else {
          console.log("Veri başarıyla eklendi:", result.rows);
          res.redirect("/managerUploadChildren");
        }
      });
    } else {
      console.error(
        "Dosya yüklenirken bir sorun oluştu: Dosya veya buffer bulunamadı."
      );
      res.status(400).send("Bad Request");
    }
  } catch (error) {
    console.error("İşlem sırasında hata oluştu:", error);
    res.status(500).send("Internal Server Error");
  }
});

// managerEditChildren route'u
app.post("/managerEditChildren", upload.single("photoedit"), (req, res) => {
  try {
    const {
      childidedit,
      fullnameedit,
      ageedit,
      genderedit,
      locationedit,
      needsedit,
    } = req.body;

    if (req.file && req.file.buffer) {
      const childphotoedit = req.file.buffer;

      const query = `
        UPDATE childrens
        SET fullname = $2, age = $3, gender = $4, location = $5, needs = $6, childphoto = $7
        WHERE childid = $1
      `;

      const values = [
        childidedit,
        fullnameedit,
        ageedit,
        genderedit,
        locationedit,
        needsedit,
        childphotoedit,
      ];

      pool.query(query, values, (error, result) => {
        if (error) {
          console.error("Veritabanına veri eklerken hata oluştu:", error);
          res.status(500).send("Internal Server Error");
        } else {
          console.log("Veri başarıyla güncellendi:", result.rows);
        }
      });
    } else {
      console.error(
        "Dosya yüklenirken bir sorun oluştu: Dosya veya buffer bulunamadı."
      );
      res.status(400).send("Bad Request");
    }
  } catch (error) {
    console.error("İşlem sırasında hata oluştu:", error);
    res.status(500).send("Internal Server Error");
  }
});

// managerEditChildren route'u
app.get("/managerEditChildren", (req, res) => {
  pool.query("SELECT * FROM childrens", (err, result) => {
    if (err) {
      console.error("Veritabanından veri çekerken hata oluştu:", err);
      return res.status(500).json({ error: err.message });
    }
    res.render("managerEditChildren", { children: result.rows });
  });
});

// Sunucuyu başlat
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
