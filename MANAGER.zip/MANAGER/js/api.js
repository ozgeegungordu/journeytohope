const express = require('express');
const { Client } = require('pg');
const bodyParser = require('body-parser');

const app = express();
const port = 3300;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

const client = new Client({
    host: "localhost",
    user: "postgres",
    port: 5432,
    password: "redfooredfoo88",
    database: "postgres"
});

client.connect();

app.listen(port, () => {
  console.log(`Server is now listening at port ${port}`);
});

app.get('/register', (req, res) => {
  client.query('SELECT * FROM "register"', (err, result) => {
    if (!err) {
      res.send(result.rows);
    } else {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
    }
  });
});

app.get('/register/:id', (req, res) => {
  const userId = req.params.id;
  client.query(`SELECT * FROM "register" WHERE regid=${userId}`, (err, result) => {
    if (!err) {
      res.send(result.rows);
    } else {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
    }
  });
});

app.post('/register', (req, res) => {
  const user = req.body;
  const insertQuery = `INSERT INTO "register" (regid, full-name, email, phone, password ) 
                       VALUES (${user.regid}, '${user.fullname}', '${user.email}', '${user.phone}', '${user.password}')`;

  client.query(insertQuery, (err, result) => {
    if (!err) {
      res.send('Insertion was successful');
    } else {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
    }
  });
});

// Don't close the connection after each query
// client.end();


app.post('/register', (req, res) => {
    const user = req.body;
  
    // Using parameterized query to prevent SQL injection
    const insertQuery = `INSERT INTO "register" (regid, "full-name", email, phone, password) 
                         VALUES ($1, $2, $3, $4, $5)`;
  
    const values = [user.regid, user.fullname, user.email, user.phone, user.password];
  
    client.query(insertQuery, values, (err, result) => {
      if (!err) {
        res.status(201).json({ message: 'Insertion was successful' });
      } else {
        console.error(err);
        res.status(500).json({ message: 'Failed to register user' });
      }
    });
  });