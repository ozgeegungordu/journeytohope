// Get the form and button elements
const form = document.getElementById('signInForm');
const signInButton = document.getElementById('sign-in');

// Add click event listener to the sign-in button
signInButton.addEventListener('click', function(event) {
  event.preventDefault(); // Prevent the default form submission behavior

  // Get input values
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Check if email and password are correct
  if (email === 'admin@admin.com' && password === 'admin') {
    // Redirect to index.html
    window.location.href = 'index1.html';
  } else {
    // Incorrect credentials handling (optional: display an error message)
    console.log('Invalid credentials. Please try again.');
  }

});