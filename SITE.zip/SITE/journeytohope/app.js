const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");
const stripe = require("stripe")("sk_test_your_stripe_secret_key");

// PostgreSQL connection informations
const pool = new Pool({
  username: "postgres",
  password: "AVNS_D83ixMFE3Kn5ddMVQQz",
  host: "db-postgresql-fra1-56784-do-user-15448575-0.c.db.ondigitalocean.com",
  port: "25060",
  database: "defaultdb",
  ssl: {
    ca: fs.readFileSync(path.join(__dirname, "ca-certificate.crt")), // CA certificate for Database
  },
});

const app = express();
const PORT = 5502;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(bodyParser.json());
app.use(
  session({ secret: "your-secret-key", resave: false, saveUninitialized: true })
);
app.set("view engine", "ejs");
app.use("/SITE/journeytohope/css", express.static(path.join(__dirname, "css")));
app.use("/SITE/journeytohope/img", express.static(path.join(__dirname, "img")));
app.use("/SITE/journeytohope/js", express.static(path.join(__dirname, "js")));
app.use(
  "/SITE/journeytohope/img/children",
  express.static(path.join(__dirname, "img/children"))
);
app.use(
  "/SITE/journeytohope/img/developers",
  express.static(path.join(__dirname, "img/developers"))
);
app.use(
  "/SITE/journeytohope/img/logo",
  express.static(path.join(__dirname, "img/logo"))
);
app.use(
  "/SITE/journeytohope/img/logos",
  express.static(path.join(__dirname, "img/logos"))
);
app.use(
  "/SITE/journeytohope/img/main",
  express.static(path.join(__dirname, "img/main"))
);
app.use(
  "/SITE/journeytohope/img/ourchildren",
  express.static(path.join(__dirname, "img/ourchildren"))
);
app.use(
  "/SITE/journeytohope/img/sponsors",
  express.static(path.join(__dirname, "img/sponsors"))
);

app.get("/", (req, res) => {
  res.render("index");
});


app.get("/children", async (req, res) => {
  try {
    // Veritabanından çocuk verilerini çek
    const result = await pool.query("SELECT * FROM childrens");
    const children = result.rows;

    // EJS şablonunu render et ve çocuk verilerini gönder
    res.render("children", { children });
  } catch (error) {
    console.error("Error fetching data from the database:", error);
    res.status(500).send("Internal Server Error");
  }
});


const requireLogin = (req, res, next) => {
  if (req.session && req.session.userId) {
    next();
  } else {
    res.redirect("signin");
  }
};

app.get("/signin", (req, res) => {
  res.render("signin");
});

app.post("/signin", (req, res) => {
  const { email, password } = req.body;

  // check the user
  pool.query(
    'SELECT * FROM public."sponsor" WHERE email = $1 AND password = $2',
    [email, password],
    (error, result) => {
      if (error) {
        console.error("Error executing SELECT query:", error);
        res.status(500).send("Internal Server Error");
      } else {
        if (result.rows.length > 0) {
          req.session.userId = result.rows[0].id;
          req.session.userEmail = result.rows[0].email;
          res.redirect("index-login");
        } else {
          res.send("Wrong Email or Password");
        }
      }
    }
  );
});

app.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.redirect("/");
    }
    res.redirect("signin");
  });
});

// Register
app.post("/index", (req, res) => {
  const FullName = req.body.FullName;
  const Email = req.body.Email;
  const PhoneNumber = req.body.PhoneNumber;
  const Password = req.body.Password;

  pool.query('SELECT * FROM public."sponsor"', (error, result) => {
    if (error) {
      console.error("Error executing SELECT query:", error);
    } else {
      console.log("SELECT query result:", result.rows);
    }
  });

  pool.query(
    'INSERT INTO public."sponsor" (FullName, Email, Password, PhoneNumber) VALUES ($1, $2, $3, $4)',
    [FullName, Email, Password, PhoneNumber],
    (error, result) => {
      if (error) {
        console.error("Error executing INSERT query:", error);

        res.send("Kayıt Sırasında hata oluştu lütfen tekrar deneyiniz!");
        //res.send(
        //  "Please enter the full name, email address, password, phone number correctly."
        //);
      } else {
        console.log("INSERT query result:", result.rows);
        //res.send("Register Succesfully");
      }
    }
  );
});

//ProfilePage

app.get("/profilpage", (req, res) => {
  const userEmail = req.session.userEmail;

  pool.query(
    "SELECT fullname, email, phonenumber, sponsorphoto FROM sponsor WHERE email = $1",
    [userEmail],
    (error, result) => {
      if (error) {
        console.error("Sorgu hatası", error);
        res.status(500).send("İç Sunucu Hatası");
      } else {
        if (result.rows.length > 0) {
          const user = result.rows[0];
          res.render("profilpage", {
            email: user.email,
            fullname: user.fullname,
            phonenumber: user.phonenumber,
            sponsorphoto: user.sponsorphoto,
          });
        } else {
          res.status(404).send("User not found.");
        }
      }
    }
  );
});

//Edit_Profile

app.get("/edit_profil", (req, res) => {
  const userEmail = req.session.userEmail;

  pool.query(
    "SELECT fullname, email, phonenumber, sponsorphoto FROM sponsor WHERE email = $1",
    [userEmail],
    (error, result) => {
      if (error) {
        console.error("Sorgu hatası", error);
        res.status(500).send("İç Sunucu Hatası");
      } else {
        if (result.rows.length > 0) {
          const user = result.rows[0];
          // Pass the necessary variables to the template
          res.render("edit_profil", {
            fullname: user.fullname,
            email: user.email,
            phonenumber: user.phonenumber,
            sponsorphoto: user.sponsorphoto,
          });
        } else {
          res.status(404).send("User not found.");
        }
      }
    }
  );
});

app.put("/edit_profil", async (req, res) => {
  try {
    const userEmail = req.session.userEmail;
    const { fullname, newEmail, newPhoneNumber, newPassword, currentPassword, sponsorphoto } =
      req.body;

    // Perform validation and update logic here

    // Update user profile in the database
    pool.query(
      "UPDATE sponsor SET fullname = $1, email = $2, password = $3, phonenumber = $4 WHERE email = $5",
      [fullname, newEmail, newPassword, newPhoneNumber, userEmail],
      (error, result) => {
        if (error) {
          console.error("Güncelleme hatası", error);
          res.status(500).send(`Güncelleme hatası: ${error.message}`);
        } else {
          res.status(200).send("Profil bilgileri güncellendi");
        }
      }
    );
  } catch (error) {
    console.error("Unexpected error:", error);
    res.status(500).send(`Unexpected Server Error: ${error.message}`);
  }
});

app.post("/edit_profil", async (req, res) => {
  const userEmail = req.session.userEmail;
  const { fullname, newEmail, newPhoneNumber, newPassword, currentPassword } =
    req.body;
   

  // // Kullanıcının mevcut şifresini doğrula
  // const passwordCheck = await checkPassword(userEmail, currentPassword);

  // if (!passwordCheck) {
  //   return res.status(401).send("Mevcut şifre doğrulanamadı");
  // }

  // Kullanıcı bilgilerini güncelle
  pool.query(
    "UPDATE sponsor SET fullname = $1, email = $2, password = $3, phonenumber = $4 WHERE email = $5",
    [fullname, newEmail, newPassword, newPhoneNumber, userEmail],
    (error, result) => {
      if (error) {
        console.error("Güncelleme hatası", error);
        res.status(500).send("İç Sunucu Hatası");
      } else {
        res.status(200).send("Profil bilgileri güncellendi");
      }
    }
  );
});

app.get("/index-login", (req, res) => {
  const userEmail = req.session.userEmail;

  pool.query(
    "SELECT fullname, email, phonenumber, sponsorphoto FROM sponsor WHERE email = $1",
    [userEmail],
    (error, result) => {
      if (error) {
        console.error("Sorgu hatası", error);
        res.status(500).send("İç Sunucu Hatası");
      } else {
        if (result.rows.length > 0) {
          const user = result.rows[0];
          res.render("index-login", {
            email: user.email,
            fullname: user.fullname,
            phonenumber: user.phonenumber,
            sponsorphoto: user.sponsorphoto,
          });
        } else {
          res.status(404).send("User not found.");
        }
      }
    }
  );
}); 




app.get("/DonationSuccessful", (req, res) => {
  const userEmail = req.session.userEmail;

  pool.query(
    "SELECT fullname, email, phonenumber, sponsorphoto FROM sponsor WHERE email = $1",
    [userEmail],
    (error, result) => {
      if (error) {
        console.error("Sorgu hatası", error);
        res.status(500).send("İç Sunucu Hatası");
      } else {
        if (result.rows.length > 0) {
          const user = result.rows[0];
          res.render("DonationSuccessful", {
            email: user.email,
            fullname: user.fullname,
            phonenumber: user.phonenumber,
            sponsorphoto: user.sponsorphoto,
          });
        } else {
          res.status(404).send("User not found.");
        }
      }
    }
  );
});

// // Kullanıcının mevcut şifresini kontrol etme fonksiyonu
// async function checkPassword(userEmail, currentPassword) {
//   const result = await pool.query(
//     "SELECT password FROM sponsor WHERE email = $1",
//     [userEmail]
//   );

//   if (result.rows.length > 0) {
//     const hashedPassword = result.rows[0].password;
//     return await bcrypt.compare(currentPassword, hashedPassword);
//   }

//   return false;
// }

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

const dns = require("dns");
dns.setDefaultResultOrder("ipv4first");
require("http").get("http://localhost:5502/", (res) =>
  console.log(res.statusCode)
);