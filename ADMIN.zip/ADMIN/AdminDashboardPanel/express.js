const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const path = require("path");
const ejs = require("ejs");
const { Pool } = require("pg");
const fs = require("fs");
const stripe = require("stripe")("sk_test_your_stripe_secret_key");


const app = express();
const PORT = 5500;

// PostgreSQL connection informations
const pool = new Pool({
  username: "postgres",
  password: "AVNS_D83ixMFE3Kn5ddMVQQz",
  host: "db-postgresql-fra1-56784-do-user-15448575-0.c.db.ondigitalocean.com",
  port: "25060",
  database: "defaultdb",
  ssl: {
    ca: fs.readFileSync(path.join(__dirname, "ca-certificate.crt")), // CA certificate for Database
  },
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(bodyParser.json());

// Session middleware configuration
app.use(
  session({ secret: "your-secret-key", resave: false, saveUninitialized: true })
);

// Static file serving
app.set("view engine", "ejs");
app.use("/ADMIN/AdminDashboardPanel/css", express.static(path.join(__dirname, "css")));
app.use("/ADMIN/AdminDashboardPanel/js", express.static(path.join(__dirname, "js")));
app.use("/ADMIN/AdminDashboardPanel/Images", express.static(path.join(__dirname, "Images")));


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(bodyParser.json());

// Signin Page
app.get('/', (req, res) => {
  res.render(path.join('signin'));
});

app.get('/donation', (req, res) => {
  res.render('donation');
});

app.get('/analytics', (req, res) => {
  res.render('analytics');
});


app.get('/index', (req, res) => {
  res.render(path.join('index'));
});




/*SIGN IN*/////////////////////////////////////////////////


app.get("/signin", (req, res) => {
  res.render("signin");
});

app.post("/signin", (req, res) => {
  const { adminemail, adminpassword } = req.body;

  // check the user
  pool.query(
    'SELECT * FROM public."admin" WHERE adminemail = $1 AND adminpassword = $2',
    [adminemail, adminpassword],
    (error, result) => {
      if (error) {
        console.error("Error executing SELECT query:", error);
        res.status(500).send("Internal Server Error");
      } else {
        if (result.rows.length > 0) {
          req.session.userId = result.rows[0].id;
          req.session.adminemail = result.rows[0].adminemail;
          res.redirect("index");
        } else {
          res.send("Wrong Email or Password");
        }
      }
    }
  );
});


app.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.redirect("/");
    }
    res.redirect("index");
  });
});


//////////////////////////////////////////////////////



/*Sponsor*/////////////////////////////////////


app.get('/sponsor', (req, res) => {
  // PostgreSQL'den sponsor tablosundaki verileri çek
  pool.query('SELECT * FROM sponsor', (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }
      // EJS şablonunu kullanarak verileri görüntüle
      res.render('sponsor', { sponsors: result.rows }); // "sponsor" dosyasını doğru şekilde belirtin
  });
});


/////////////////////////////////////////////////////////

/*Manager Page */////////////////////////


app.get('/manager', (req, res) => {
  // PostgreSQL'den sponsor tablosundaki verileri çek
  pool.query('SELECT * FROM manager', (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }
      // EJS şablonunu kullanarak verileri görüntüle
      res.render('manager', { managers: result.rows }); // "sponsor" dosyasını doğru şekilde belirtin
  });
});


/////////////////////////////////////////



const requireLogin = (req, res, next) => {
  if (req.session && req.session.userId) {
    next();
  } else {
    res.redirect('signin');
  }
};

app.get("/index", requireLogin, (req, res) => {
  const user = users.find((u) => u.id === req.session.userId);

  res.render("index", { email: user.email });
});



// Sunucuyu başlat
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

const dns = require("dns");
dns.setDefaultResultOrder("ipv4first");
require("http").get("http://localhost:5500/", (res) =>
  console.log(res.statusCode)
);