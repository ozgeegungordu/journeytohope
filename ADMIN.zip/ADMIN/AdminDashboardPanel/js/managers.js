var managers = [
    { name: "Ahmet", position: "CEO", country: "Turkey", email: "ahmet@example.com", image: "https://placekitten.com/100/100" },
    { name: "John", position: "CTO", country: "USA", email: "john@example.com", image: "https://placekitten.com/100/101" },
    // Diğer yöneticileri buraya ekleyebilirsiniz.
];

function renderManagerCards(filteredManagers) {
    var container = document.getElementById("manager-container");
    container.innerHTML = "";

    (filteredManagers || managers).forEach(function(manager, index) {
        var card = document.createElement("div");
        card.className = "manager-card";
        card.innerHTML = `<img src="${manager.image}" alt="${manager.name}" class="manager-image">
                          <p>${manager.name}</p>
                          <p>${manager.position}</p>
                          <p>${manager.country}</p>
                          <p>${manager.email}</p>
                          <button onclick="editManager(${index})">Düzenle</button>
                          <button onclick="deleteManager('${manager.name}')">Sil</button>
                          <button onclick="sendMail('${manager.email}')">Mail Gönder</button>`;
        container.appendChild(card);
    });
}

function showManagerForm() {
    document.getElementById("overlay").style.display = "flex";
}

function closeOverlay() {
    document.getElementById("overlay").style.display = "none";
}

function saveManager() {
    var name = document.getElementById("name").value;
    var position = document.getElementById("position").value;
    var country = document.getElementById("country").value;
    var email = document.getElementById("email").value;
    var image = document.getElementById("image").value;

    if (name && position && country && email && image) {
        // Edit mode kontrolü
        var editIndex = document.getElementById("edit-index").value;
        if (editIndex !== "") {
            managers[editIndex] = { name: name, position: position, country: country, email: email, image: image };
            document.getElementById("edit-index").value = "";
        } else {
            managers.push({ name: name, position: position, country: country, email: email, image: image });
        }

        closeOverlay();
        renderManagerCards();
    } else {
        alert("Lütfen tüm alanları doldurun.");
    }
}

function editManager(index) {
    var manager = managers[index];
    document.getElementById("name").value = manager.name;
    document.getElementById("position").value = manager.position;
    document.getElementById("country").value = manager.country;
    document.getElementById("email").value = manager.email;
    document.getElementById("image").value = manager.image;

    // Düzenleme modunu ayarla
    document.getElementById("edit-index").value = index;

    showManagerForm(); // Formu göster
}

function deleteManager(name) {
    var confirmDelete = confirm("Bu yöneticiyi silmek istediğinizden emin misiniz?");
    
    if (confirmDelete) {
        var index = managers.findIndex(manager => manager.name === name);
        if (index !== -1) {
            managers.splice(index, 1);
            renderManagerCards();
        }
    }
}

function searchManager() {
    var searchTerm = document.getElementById("search").value.toLowerCase();
    var filteredManagers = managers.filter(manager =>
        manager.name.toLowerCase().includes(searchTerm) ||
        manager.country.toLowerCase().includes(searchTerm)
    );
    renderManagerCards(filteredManagers);
}

function sendMail(email) {
    window.location.href = "mailto:" + email;
}

        // Formu temizle
        document.getElementById("manager-form").reset();

        closeOverlay();

        // Call renderManagerCards after adding a new manager
        renderManagerCards();