const express = require('express');
const app = express();
const PORT = 5500;

app.use(express.static('public'));

app.get('https://api.srv3r.com/table/', (req, res) => {
  // Implement your logic to fetch data from the API here
  // For testing purposes, you can return dummy data
  const dummyData = [
    { id: 1, guid: 'abc123', name: 'Lion', status: 'Active' },
    { id: 2, guid: 'def456', name: 'Elephant', status: 'Inactive' },
    // Add more dummy data as needed
  ];

  res.json(dummyData);
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
