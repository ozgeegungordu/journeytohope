document.addEventListener("DOMContentLoaded", function() {
    // Set the goal amount and the raised amount
    var goalAmount = 10000;
    var raisedAmount = 3750;

    // Calculate the percentage of the goal reached
    var percentage = (raisedAmount / goalAmount) * 100;

    // Update the width of the progress bar
    document.getElementById("progress").style.width = percentage + "%";
});